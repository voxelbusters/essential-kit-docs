1. Extract the contents of the zip and place it under Assets/Plugins/Android folder
2. Make an apk/aab

Credits: 
https://assetstore.unity.com/publishers/11527
voxelbusters.com